/* tslint:disable */
/* eslint-disable */
/**
 * 
 * @export
 * @interface AcceptAgentRuleRequestDTO
 */
export interface AcceptAgentRuleRequestDTO {
    /**
     * Updated rule title before activation.
     * @type {string}
     * @memberof AcceptAgentRuleRequestDTO
     */
    title?: string;
    /**
     * Updated rule content before activation.
     * @type {string}
     * @memberof AcceptAgentRuleRequestDTO
     */
    content?: string;
}
/**
 * 
 * @export
 * @interface AddAgentToProjectRequestDTO
 */
export interface AddAgentToProjectRequestDTO {
    /**
     * Existing user-owned agent identifier.
     * @type {string}
     * @memberof AddAgentToProjectRequestDTO
     */
    agentId: string;
}
/**
 * 
 * @export
 * @interface AgentConversationDTO
 */
export interface AgentConversationDTO {
    /**
     * Conversation identifier.
     * @type {string}
     * @memberof AgentConversationDTO
     */
    id: string;
    /**
     * Conversation title.
     * @type {string}
     * @memberof AgentConversationDTO
     */
    title: string;
    /**
     * Conversation type.
     * @type {string}
     * @memberof AgentConversationDTO
     */
    type: AgentConversationDTOTypeEnum;
    /**
     * Conversation creation timestamp (UTC).
     * @type {string}
     * @memberof AgentConversationDTO
     */
    createdAt: string;
    /**
     * Last conversation update timestamp (UTC).
     * @type {string}
     * @memberof AgentConversationDTO
     */
    updatedAt: string;
    /**
     * Last message timestamp for list sorting (UTC).
     * @type {string}
     * @memberof AgentConversationDTO
     */
    lastMessageAt: string;
    /**
     * 
     * @type {ChatExecutionDTO1}
     * @memberof AgentConversationDTO
     */
    latestExecution?: ChatExecutionDTO1 | null;
}


/**
 * @export
 */
export const AgentConversationDTOTypeEnum = {
    DIRECT: 'DIRECT',
    MULTI_AGENT: 'MULTI_AGENT'
} as const;
export type AgentConversationDTOTypeEnum = typeof AgentConversationDTOTypeEnum[keyof typeof AgentConversationDTOTypeEnum];

/**
 * 
 * @export
 * @interface AgentConversationDTO1
 */
export interface AgentConversationDTO1 {
    /**
     * Conversation identifier.
     * @type {string}
     * @memberof AgentConversationDTO1
     */
    id: string;
    /**
     * Conversation title.
     * @type {string}
     * @memberof AgentConversationDTO1
     */
    title: string;
    /**
     * Conversation type.
     * @type {string}
     * @memberof AgentConversationDTO1
     */
    type: AgentConversationDTO1TypeEnum;
    /**
     * Conversation creation timestamp (UTC).
     * @type {string}
     * @memberof AgentConversationDTO1
     */
    createdAt: string;
    /**
     * Last conversation update timestamp (UTC).
     * @type {string}
     * @memberof AgentConversationDTO1
     */
    updatedAt: string;
    /**
     * Last message timestamp for list sorting (UTC).
     * @type {string}
     * @memberof AgentConversationDTO1
     */
    lastMessageAt: string;
    /**
     * 
     * @type {ChatExecutionDTO}
     * @memberof AgentConversationDTO1
     */
    latestExecution?: ChatExecutionDTO | null;
}


/**
 * @export
 */
export const AgentConversationDTO1TypeEnum = {
    DIRECT: 'DIRECT',
    MULTI_AGENT: 'MULTI_AGENT'
} as const;
export type AgentConversationDTO1TypeEnum = typeof AgentConversationDTO1TypeEnum[keyof typeof AgentConversationDTO1TypeEnum];

/**
 * 
 * @export
 * @interface AgentConversationDetailsDTO
 */
export interface AgentConversationDetailsDTO {
    /**
     * Conversation identifier.
     * @type {string}
     * @memberof AgentConversationDetailsDTO
     */
    id: string;
    /**
     * Conversation title.
     * @type {string}
     * @memberof AgentConversationDetailsDTO
     */
    title: string;
    /**
     * Conversation type.
     * @type {string}
     * @memberof AgentConversationDetailsDTO
     */
    type: AgentConversationDetailsDTOTypeEnum;
    /**
     * Conversation creation timestamp (UTC).
     * @type {string}
     * @memberof AgentConversationDetailsDTO
     */
    createdAt: string;
    /**
     * Last conversation update timestamp (UTC).
     * @type {string}
     * @memberof AgentConversationDetailsDTO
     */
    updatedAt: string;
    /**
     * Last message timestamp (UTC).
     * @type {string}
     * @memberof AgentConversationDetailsDTO
     */
    lastMessageAt: string;
    /**
     * Full ordered message history.
     * @type {Array<AgentConversationMessageDTO>}
     * @memberof AgentConversationDetailsDTO
     */
    messages: Array<AgentConversationMessageDTO>;
    /**
     * 
     * @type {ChatExecutionDTO}
     * @memberof AgentConversationDetailsDTO
     */
    execution?: ChatExecutionDTO;
}


/**
 * @export
 */
export const AgentConversationDetailsDTOTypeEnum = {
    DIRECT: 'DIRECT',
    MULTI_AGENT: 'MULTI_AGENT'
} as const;
export type AgentConversationDetailsDTOTypeEnum = typeof AgentConversationDetailsDTOTypeEnum[keyof typeof AgentConversationDetailsDTOTypeEnum];

/**
 * 
 * @export
 * @interface AgentConversationMessageDTO
 */
export interface AgentConversationMessageDTO {
    /**
     * Message identifier.
     * @type {string}
     * @memberof AgentConversationMessageDTO
     */
    id: string;
    /**
     * Message author type.
     * @type {string}
     * @memberof AgentConversationMessageDTO
     */
    authorType: AgentConversationMessageDTOAuthorTypeEnum;
    /**
     * Message author identifier.
     * @type {string}
     * @memberof AgentConversationMessageDTO
     */
    authorId: string;
    /**
     * Persisted message content.
     * @type {string}
     * @memberof AgentConversationMessageDTO
     */
    content: string;
    /**
     * Message creation timestamp (UTC).
     * @type {string}
     * @memberof AgentConversationMessageDTO
     */
    createdAt: string;
}


/**
 * @export
 */
export const AgentConversationMessageDTOAuthorTypeEnum = {
    USER: 'USER',
    AGENT: 'AGENT'
} as const;
export type AgentConversationMessageDTOAuthorTypeEnum = typeof AgentConversationMessageDTOAuthorTypeEnum[keyof typeof AgentConversationMessageDTOAuthorTypeEnum];

/**
 * 
 * @export
 * @interface AgentConversationsResponseDTO
 */
export interface AgentConversationsResponseDTO {
    /**
     * Conversations for one agent and current user.
     * @type {Array<AgentConversationDTO1>}
     * @memberof AgentConversationsResponseDTO
     */
    items: Array<AgentConversationDTO1>;
}
/**
 * 
 * @export
 * @interface AgentDTO
 */
export interface AgentDTO {
    /**
     * Globally unique agent identifier.
     * @type {string}
     * @memberof AgentDTO
     */
    id: string;
    /**
     * Agent name.
     * @type {string}
     * @memberof AgentDTO
     */
    name: string;
    /**
     * Agent description.
     * @type {string}
     * @memberof AgentDTO
     */
    description?: string;
    /**
     * Agent behavioral definition text.
     * @type {string}
     * @memberof AgentDTO
     */
    instruction?: string;
    /**
     * Current agent status.
     * @type {string}
     * @memberof AgentDTO
     */
    status: AgentDTOStatusEnum;
    /**
     * Agent creation timestamp (UTC).
     * @type {string}
     * @memberof AgentDTO
     */
    createdAt: string;
    /**
     * Last agent update timestamp (UTC).
     * @type {string}
     * @memberof AgentDTO
     */
    updatedAt: string;
}


/**
 * @export
 */
export const AgentDTOStatusEnum = {
    DRAFT: 'DRAFT',
    ACTIVE: 'ACTIVE',
    ARCHIVED: 'ARCHIVED',
    DELETED: 'DELETED'
} as const;
export type AgentDTOStatusEnum = typeof AgentDTOStatusEnum[keyof typeof AgentDTOStatusEnum];

/**
 * 
 * @export
 * @interface AgentProjectDTO
 */
export interface AgentProjectDTO {
    /**
     * Globally unique project identifier.
     * @type {string}
     * @memberof AgentProjectDTO
     */
    id: string;
    /**
     * Project name.
     * @type {string}
     * @memberof AgentProjectDTO
     */
    name: string;
    /**
     * Project description.
     * @type {string}
     * @memberof AgentProjectDTO
     */
    description?: string;
    /**
     * Project-specific context that guides future agent work in this project.
     * @type {string}
     * @memberof AgentProjectDTO
     */
    context?: string | null;
    /**
     * 
     * @type {AgentProjectStatusDTO}
     * @memberof AgentProjectDTO
     */
    status: AgentProjectStatusDTO;
    /**
     * Project creation timestamp (UTC).
     * @type {string}
     * @memberof AgentProjectDTO
     */
    createdAt: string;
    /**
     * Last project update timestamp (UTC).
     * @type {string}
     * @memberof AgentProjectDTO
     */
    updatedAt: string;
}
/**
 * 
 * @export
 * @interface AgentProjectFlowEdgeDTO
 */
export interface AgentProjectFlowEdgeDTO {
    /**
     * Edge identifier.
     * @type {string}
     * @memberof AgentProjectFlowEdgeDTO
     */
    id: string;
    /**
     * Source node identifier.
     * @type {string}
     * @memberof AgentProjectFlowEdgeDTO
     */
    sourceNodeId: string;
    /**
     * Target node identifier.
     * @type {string}
     * @memberof AgentProjectFlowEdgeDTO
     */
    targetNodeId: string;
    /**
     * Edge type.
     * @type {string}
     * @memberof AgentProjectFlowEdgeDTO
     */
    edgeType: string;
    /**
     * Edge configuration payload.
     * @type {{ [key: string]: any; }}
     * @memberof AgentProjectFlowEdgeDTO
     */
    config?: { [key: string]: any; } | null;
}
/**
 * 
 * @export
 * @interface AgentProjectFlowNodeDTO
 */
export interface AgentProjectFlowNodeDTO {
    /**
     * Node identifier.
     * @type {string}
     * @memberof AgentProjectFlowNodeDTO
     */
    id: string;
    /**
     * Node type.
     * @type {string}
     * @memberof AgentProjectFlowNodeDTO
     */
    nodeType: string;
    /**
     * Optional referenced source identifier.
     * @type {string}
     * @memberof AgentProjectFlowNodeDTO
     */
    referenceId?: string | null;
    /**
     * 
     * @type {AgentProjectFlowNodePositionDTO}
     * @memberof AgentProjectFlowNodeDTO
     */
    position: AgentProjectFlowNodePositionDTO;
    /**
     * Optional design lifecycle status for the node.
     * @type {string}
     * @memberof AgentProjectFlowNodeDTO
     */
    designStatus?: string;
    /**
     * Node configuration payload.
     * @type {{ [key: string]: any; }}
     * @memberof AgentProjectFlowNodeDTO
     */
    config?: { [key: string]: any; } | null;
}
/**
 * 
 * @export
 * @interface AgentProjectFlowNodePositionDTO
 */
export interface AgentProjectFlowNodePositionDTO {
    /**
     * Horizontal coordinate.
     * @type {number}
     * @memberof AgentProjectFlowNodePositionDTO
     */
    x: number;
    /**
     * Vertical coordinate.
     * @type {number}
     * @memberof AgentProjectFlowNodePositionDTO
     */
    y: number;
}
/**
 * 
 * @export
 * @interface AgentProjectFlowPaletteResponseDTO
 */
export interface AgentProjectFlowPaletteResponseDTO {
    /**
     * Palette sources for flow design.
     * @type {Array<AgentProjectFlowPaletteSourceDTO>}
     * @memberof AgentProjectFlowPaletteResponseDTO
     */
    sources: Array<AgentProjectFlowPaletteSourceDTO>;
}
/**
 * 
 * @export
 * @interface AgentProjectFlowPaletteSourceDTO
 */
export interface AgentProjectFlowPaletteSourceDTO {
    /**
     * Source type (USER or AGENT).
     * @type {string}
     * @memberof AgentProjectFlowPaletteSourceDTO
     */
    sourceType: string;
    /**
     * Source identifier.
     * @type {string}
     * @memberof AgentProjectFlowPaletteSourceDTO
     */
    sourceId: string;
    /**
     * Source display name.
     * @type {string}
     * @memberof AgentProjectFlowPaletteSourceDTO
     */
    sourceName: string;
}
/**
 * 
 * @export
 * @interface AgentProjectFlowResponseDTO
 */
export interface AgentProjectFlowResponseDTO {
    /**
     * Persisted flow identifier; null when project has no persisted flow.
     * @type {string}
     * @memberof AgentProjectFlowResponseDTO
     */
    flowId?: string | null;
    /**
     * Flow nodes.
     * @type {Array<AgentProjectFlowNodeDTO>}
     * @memberof AgentProjectFlowResponseDTO
     */
    nodes: Array<AgentProjectFlowNodeDTO>;
    /**
     * Flow edges.
     * @type {Array<AgentProjectFlowEdgeDTO>}
     * @memberof AgentProjectFlowResponseDTO
     */
    edges: Array<AgentProjectFlowEdgeDTO>;
}

/**
 * Current project lifecycle status.
 * @export
 */
export const AgentProjectStatusDTO = {
    ACTIVE: 'ACTIVE',
    ARCHIVED: 'ARCHIVED',
    DELETED: 'DELETED'
} as const;
export type AgentProjectStatusDTO = typeof AgentProjectStatusDTO[keyof typeof AgentProjectStatusDTO];

/**
 * 
 * @export
 * @interface AgentProjectsPageResponseDTO
 */
export interface AgentProjectsPageResponseDTO {
    /**
     * Persisted automation projects.
     * @type {Array<AgentProjectDTO>}
     * @memberof AgentProjectsPageResponseDTO
     */
    items: Array<AgentProjectDTO>;
    /**
     * 
     * @type {number}
     * @memberof AgentProjectsPageResponseDTO
     */
    page: number;
    /**
     * 
     * @type {number}
     * @memberof AgentProjectsPageResponseDTO
     */
    size: number;
    /**
     * 
     * @type {boolean}
     * @memberof AgentProjectsPageResponseDTO
     */
    hasNext: boolean;
}

/**
 * Agent rule author source.
 * @export
 */
export const AgentRuleAuthorTypeDTO = {
    USER: 'USER',
    AI: 'AI'
} as const;
export type AgentRuleAuthorTypeDTO = typeof AgentRuleAuthorTypeDTO[keyof typeof AgentRuleAuthorTypeDTO];

/**
 * 
 * @export
 * @interface AgentRuleDTO
 */
export interface AgentRuleDTO {
    /**
     * Globally unique rule identifier.
     * @type {string}
     * @memberof AgentRuleDTO
     */
    id: string;
    /**
     * Globally unique agent identifier.
     * @type {string}
     * @memberof AgentRuleDTO
     */
    agentId: string;
    /**
     * Rule title used in UI and matching.
     * @type {string}
     * @memberof AgentRuleDTO
     */
    title: string;
    /**
     * Rule content used in execution context.
     * @type {string}
     * @memberof AgentRuleDTO
     */
    content: string;
    /**
     * 
     * @type {AgentRuleStatusDTO}
     * @memberof AgentRuleDTO
     */
    status: AgentRuleStatusDTO;
    /**
     * 
     * @type {AgentRuleAuthorTypeDTO}
     * @memberof AgentRuleDTO
     */
    authorType: AgentRuleAuthorTypeDTO;
    /**
     * Rule creation timestamp (UTC).
     * @type {string}
     * @memberof AgentRuleDTO
     */
    createdAt: string;
    /**
     * Last rule update timestamp (UTC).
     * @type {string}
     * @memberof AgentRuleDTO
     */
    updatedAt: string;
}

/**
 * Agent rule lifecycle status.
 * @export
 */
export const AgentRuleStatusDTO = {
    PENDING: 'PENDING',
    ACTIVE: 'ACTIVE',
    REJECTED: 'REJECTED',
    DELETED: 'DELETED'
} as const;
export type AgentRuleStatusDTO = typeof AgentRuleStatusDTO[keyof typeof AgentRuleStatusDTO];

/**
 * 
 * @export
 * @interface AgentRulesResponseDTO
 */
export interface AgentRulesResponseDTO {
    /**
     * Automation rules for one agent.
     * @type {Array<AgentRuleDTO>}
     * @memberof AgentRulesResponseDTO
     */
    items: Array<AgentRuleDTO>;
}
/**
 * 
 * @export
 * @interface AgentsResponseDTO
 */
export interface AgentsResponseDTO {
    /**
     * Persisted automation agents.
     * @type {Array<AgentDTO>}
     * @memberof AgentsResponseDTO
     */
    items: Array<AgentDTO>;
}
/**
 * 
 * @export
 * @interface ChatAgentExecutionDTO
 */
export interface ChatAgentExecutionDTO {
    /**
     * Chat execution identifier.
     * @type {string}
     * @memberof ChatAgentExecutionDTO
     */
    executionId: string;
    /**
     * 
     * @type {ChatAgentExecutionStatusDTO}
     * @memberof ChatAgentExecutionDTO
     */
    status: ChatAgentExecutionStatusDTO;
    /**
     * Execution creation timestamp (UTC).
     * @type {string}
     * @memberof ChatAgentExecutionDTO
     */
    submittedAt: string;
    /**
     * Last execution state update timestamp (UTC).
     * @type {string}
     * @memberof ChatAgentExecutionDTO
     */
    updatedAt?: string;
    /**
     * Terminal completion timestamp (UTC).
     * @type {string}
     * @memberof ChatAgentExecutionDTO
     */
    completedAt?: string;
    /**
     * Conversation identifier linked to the execution.
     * @type {string}
     * @memberof ChatAgentExecutionDTO
     */
    conversationId: string;
    /**
     * Persisted user message identifier.
     * @type {string}
     * @memberof ChatAgentExecutionDTO
     */
    inputMessageId?: string;
    /**
     * 
     * @type {AgentConversationMessageDTO}
     * @memberof ChatAgentExecutionDTO
     */
    assistantMessage?: AgentConversationMessageDTO;
    /**
     * 
     * @type {ChatAgentExecutionFailureDTO}
     * @memberof ChatAgentExecutionDTO
     */
    failure?: ChatAgentExecutionFailureDTO;
}
/**
 * 
 * @export
 * @interface ChatAgentExecutionFailureDTO
 */
export interface ChatAgentExecutionFailureDTO {
    /**
     * Machine-consumable terminal failure code.
     * @type {string}
     * @memberof ChatAgentExecutionFailureDTO
     */
    code: string;
    /**
     * Human-readable terminal failure details.
     * @type {string}
     * @memberof ChatAgentExecutionFailureDTO
     */
    message: string;
}

/**
 * 
 * @export
 */
export const ChatAgentExecutionStatusDTO = {
    ACCEPTED: 'ACCEPTED',
    IN_PROGRESS: 'IN_PROGRESS',
    SUCCEEDED: 'SUCCEEDED',
    FAILED: 'FAILED'
} as const;
export type ChatAgentExecutionStatusDTO = typeof ChatAgentExecutionStatusDTO[keyof typeof ChatAgentExecutionStatusDTO];

/**
 * 
 * @export
 * @interface ChatAgentRequestDTO
 */
export interface ChatAgentRequestDTO {
    /**
     * Idempotency key generated by client per submit intent. Reusing the same key for an in-flight execution returns the same execution reference.
     * @type {string}
     * @memberof ChatAgentRequestDTO
     */
    clientRequestId: string;
    /**
     * Existing conversation identifier for continue-chat flow.
     * @type {string}
     * @memberof ChatAgentRequestDTO
     */
    conversationId?: string;
    /**
     * User message to persist and execute.
     * @type {string}
     * @memberof ChatAgentRequestDTO
     */
    message: string;
}
/**
 * 
 * @export
 * @interface ChatAgentResponseDTO
 */
export interface ChatAgentResponseDTO {
    /**
     * Chat execution identifier.
     * @type {string}
     * @memberof ChatAgentResponseDTO
     */
    executionId: string;
    /**
     * 
     * @type {ChatAgentExecutionStatusDTO}
     * @memberof ChatAgentResponseDTO
     */
    status: ChatAgentExecutionStatusDTO;
    /**
     * Execution creation timestamp (UTC).
     * @type {string}
     * @memberof ChatAgentResponseDTO
     */
    submittedAt: string;
    /**
     * Last execution state update timestamp (UTC).
     * @type {string}
     * @memberof ChatAgentResponseDTO
     */
    updatedAt?: string;
    /**
     * Terminal completion timestamp (UTC).
     * @type {string}
     * @memberof ChatAgentResponseDTO
     */
    completedAt?: string;
    /**
     * Conversation identifier linked to the execution.
     * @type {string}
     * @memberof ChatAgentResponseDTO
     */
    conversationId: string;
    /**
     * Persisted user message identifier.
     * @type {string}
     * @memberof ChatAgentResponseDTO
     */
    inputMessageId?: string;
    /**
     * 
     * @type {AgentConversationMessageDTO}
     * @memberof ChatAgentResponseDTO
     */
    assistantMessage?: AgentConversationMessageDTO;
    /**
     * 
     * @type {ChatAgentExecutionFailureDTO}
     * @memberof ChatAgentResponseDTO
     */
    failure?: ChatAgentExecutionFailureDTO;
}
/**
 * 
 * @export
 * @interface ChatExecutionDTO
 */
export interface ChatExecutionDTO {
    /**
     * Execution identifier.
     * @type {string}
     * @memberof ChatExecutionDTO
     */
    executionId: string;
    /**
     * Conversation identifier linked to this execution.
     * @type {string}
     * @memberof ChatExecutionDTO
     */
    conversationId: string;
    /**
     * 
     * @type {ExecutionStatusDTO}
     * @memberof ChatExecutionDTO
     */
    status: ExecutionStatusDTO;
    /**
     * Execution acceptance timestamp (UTC).
     * @type {string}
     * @memberof ChatExecutionDTO
     */
    acceptedAt: string;
    /**
     * Execution start timestamp (UTC).
     * @type {string}
     * @memberof ChatExecutionDTO
     */
    startedAt?: string | null;
    /**
     * Terminal execution timestamp (UTC).
     * @type {string}
     * @memberof ChatExecutionDTO
     */
    completedAt?: string | null;
    /**
     * 
     * @type {ChatExecutionFailureDTO}
     * @memberof ChatExecutionDTO
     */
    error?: ChatExecutionFailureDTO | null;
    /**
     * 
     * @type {AgentConversationMessageDTO}
     * @memberof ChatExecutionDTO
     */
    assistantMessage?: AgentConversationMessageDTO | null;
}
/**
 * 
 * @export
 * @interface ChatExecutionDTO1
 */
export interface ChatExecutionDTO1 {
    /**
     * Execution identifier.
     * @type {string}
     * @memberof ChatExecutionDTO1
     */
    executionId: string;
    /**
     * Conversation identifier linked to this execution.
     * @type {string}
     * @memberof ChatExecutionDTO1
     */
    conversationId: string;
    /**
     * 
     * @type {ExecutionStatusDTO}
     * @memberof ChatExecutionDTO1
     */
    status: ExecutionStatusDTO;
    /**
     * Execution acceptance timestamp (UTC).
     * @type {string}
     * @memberof ChatExecutionDTO1
     */
    acceptedAt: string;
    /**
     * Execution start timestamp (UTC).
     * @type {string}
     * @memberof ChatExecutionDTO1
     */
    startedAt?: string | null;
    /**
     * Terminal execution timestamp (UTC).
     * @type {string}
     * @memberof ChatExecutionDTO1
     */
    completedAt?: string | null;
    /**
     * 
     * @type {ChatExecutionFailureDTO}
     * @memberof ChatExecutionDTO1
     */
    error?: ChatExecutionFailureDTO | null;
    /**
     * 
     * @type {AgentConversationMessageDTO}
     * @memberof ChatExecutionDTO1
     */
    assistantMessage?: AgentConversationMessageDTO | null;
}
/**
 * 
 * @export
 * @interface ChatExecutionFailureDTO
 */
export interface ChatExecutionFailureDTO {
    /**
     * Machine-readable terminal failure code.
     * @type {string}
     * @memberof ChatExecutionFailureDTO
     */
    code: string;
    /**
     * Human-readable terminal failure message.
     * @type {string}
     * @memberof ChatExecutionFailureDTO
     */
    message: string;
    /**
     * Optional machine-readable failure details.
     * @type {{ [key: string]: any; }}
     * @memberof ChatExecutionFailureDTO
     */
    details?: { [key: string]: any; };
}
/**
 * 
 * @export
 * @interface CreateAgentProjectRequestDTO
 */
export interface CreateAgentProjectRequestDTO {
    /**
     * Human-readable agent project name. Value is trimmed before validation.
     * @type {string}
     * @memberof CreateAgentProjectRequestDTO
     */
    name: string;
    /**
     * Optional project description. Value is trimmed before persistence.
     * @type {string}
     * @memberof CreateAgentProjectRequestDTO
     */
    description?: string;
}
/**
 * 
 * @export
 * @interface CreateAgentRequestDTO
 */
export interface CreateAgentRequestDTO {
    /**
     * Human-readable agent name. Value is trimmed before validation.
     * @type {string}
     * @memberof CreateAgentRequestDTO
     */
    name: string;
    /**
     * Short description of the agent responsibility.
     * @type {string}
     * @memberof CreateAgentRequestDTO
     */
    description?: string;
}
/**
 * 
 * @export
 * @interface CreateAgentRuleRequestDTO
 */
export interface CreateAgentRuleRequestDTO {
    /**
     * Rule title. Value is trimmed before validation.
     * @type {string}
     * @memberof CreateAgentRuleRequestDTO
     */
    title: string;
    /**
     * Rule content. Value is trimmed before validation.
     * @type {string}
     * @memberof CreateAgentRuleRequestDTO
     */
    content: string;
}
/**
 * 
 * @export
 * @interface CreateProjectConversationRequestDTO
 */
export interface CreateProjectConversationRequestDTO {
    /**
     * Selected attached agent identifiers.
     * @type {Set<string>}
     * @memberof CreateProjectConversationRequestDTO
     */
    agentIds: Set<string>;
}
/**
 * 
 * @export
 * @interface CreateSiteRequestDTO
 */
export interface CreateSiteRequestDTO {
    /**
     * Human-readable site name. Value is trimmed before validation. Duplicate names are allowed.
     * @type {string}
     * @memberof CreateSiteRequestDTO
     */
    name: string;
    /**
     * Logical site category used for onboarding and analytics.
     * @type {string}
     * @memberof CreateSiteRequestDTO
     */
    type?: CreateSiteRequestDTOTypeEnum;
    /**
     * Short site description.
     * @type {string}
     * @memberof CreateSiteRequestDTO
     */
    description?: string;
    /**
     * Initial template identifier used during site creation.
     * @type {string}
     * @memberof CreateSiteRequestDTO
     */
    template?: CreateSiteRequestDTOTemplateEnum;
}


/**
 * @export
 */
export const CreateSiteRequestDTOTypeEnum = {
    PORTFOLIO: 'PORTFOLIO',
    BUSINESS: 'BUSINESS',
    BLOG: 'BLOG',
    STORE: 'STORE',
    LANDING: 'LANDING',
    OTHER: 'OTHER'
} as const;
export type CreateSiteRequestDTOTypeEnum = typeof CreateSiteRequestDTOTypeEnum[keyof typeof CreateSiteRequestDTOTypeEnum];

/**
 * @export
 */
export const CreateSiteRequestDTOTemplateEnum = {
    BLANK: 'BLANK'
} as const;
export type CreateSiteRequestDTOTemplateEnum = typeof CreateSiteRequestDTOTemplateEnum[keyof typeof CreateSiteRequestDTOTemplateEnum];

/**
 * 
 * @export
 * @interface CreateSiteResponseDTO
 */
export interface CreateSiteResponseDTO {
    /**
     * Globally unique site identifier.
     * @type {string}
     * @memberof CreateSiteResponseDTO
     */
    siteId: string;
    /**
     * Site name.
     * @type {string}
     * @memberof CreateSiteResponseDTO
     */
    name: string;
    /**
     * Current site status.
     * @type {string}
     * @memberof CreateSiteResponseDTO
     */
    status: CreateSiteResponseDTOStatusEnum;
    /**
     * Site creation timestamp (UTC).
     * @type {string}
     * @memberof CreateSiteResponseDTO
     */
    createdAt: string;
    /**
     * Last site update timestamp (UTC).
     * @type {string}
     * @memberof CreateSiteResponseDTO
     */
    updatedAt: string;
}


/**
 * @export
 */
export const CreateSiteResponseDTOStatusEnum = {
    DRAFT: 'DRAFT',
    PUBLISHED: 'PUBLISHED',
    ARCHIVED: 'ARCHIVED'
} as const;
export type CreateSiteResponseDTOStatusEnum = typeof CreateSiteResponseDTOStatusEnum[keyof typeof CreateSiteResponseDTOStatusEnum];

/**
 * 
 * @export
 * @interface DeleteAgentRuleResponseDTO
 */
export interface DeleteAgentRuleResponseDTO {
    /**
     * Rule status after delete action.
     * @type {string}
     * @memberof DeleteAgentRuleResponseDTO
     */
    status: DeleteAgentRuleResponseDTOStatusEnum;
}


/**
 * @export
 */
export const DeleteAgentRuleResponseDTOStatusEnum = {
    DELETED: 'DELETED'
} as const;
export type DeleteAgentRuleResponseDTOStatusEnum = typeof DeleteAgentRuleResponseDTOStatusEnum[keyof typeof DeleteAgentRuleResponseDTOStatusEnum];

/**
 * 
 * @export
 * @interface EmailVerificationDTO
 */
export interface EmailVerificationDTO {
    /**
     * 
     * @type {string}
     * @memberof EmailVerificationDTO
     */
    token: string;
    /**
     * 
     * @type {string}
     * @memberof EmailVerificationDTO
     */
    siteId?: string;
}
/**
 * 
 * @export
 * @interface EmailVerificationResponseDTO
 */
export interface EmailVerificationResponseDTO {
    /**
     * 
     * @type {string}
     * @memberof EmailVerificationResponseDTO
     */
    message?: string;
    /**
     * 
     * @type {string}
     * @memberof EmailVerificationResponseDTO
     */
    status?: EmailVerificationResponseDTOStatusEnum;
}


/**
 * @export
 */
export const EmailVerificationResponseDTOStatusEnum = {
    PENDING_EMAIL_VERIFY: 'PENDING_EMAIL_VERIFY',
    ACTIVE: 'ACTIVE',
    INACTIVE: 'INACTIVE',
    BANNED: 'BANNED'
} as const;
export type EmailVerificationResponseDTOStatusEnum = typeof EmailVerificationResponseDTOStatusEnum[keyof typeof EmailVerificationResponseDTOStatusEnum];

/**
 * 
 * @export
 * @interface ErrorDTO
 */
export interface ErrorDTO {
    /**
     * 
     * @type {number}
     * @memberof ErrorDTO
     */
    code: number;
    /**
     * 
     * @type {string}
     * @memberof ErrorDTO
     */
    title: string;
    /**
     * 
     * @type {string}
     * @memberof ErrorDTO
     */
    details: string;
}

/**
 * Canonical async execution lifecycle state.
 * @export
 */
export const ExecutionStatusDTO = {
    ACCEPTED: 'ACCEPTED',
    IN_PROGRESS: 'IN_PROGRESS',
    SUCCEEDED: 'SUCCEEDED',
    FAILED: 'FAILED'
} as const;
export type ExecutionStatusDTO = typeof ExecutionStatusDTO[keyof typeof ExecutionStatusDTO];

/**
 * 
 * @export
 * @interface LoginRequestDTO
 */
export interface LoginRequestDTO {
    /**
     * 
     * @type {string}
     * @memberof LoginRequestDTO
     */
    email: string;
    /**
     * 
     * @type {string}
     * @memberof LoginRequestDTO
     */
    password: string;
    /**
     * 
     * @type {string}
     * @memberof LoginRequestDTO
     */
    siteId?: string;
    /**
     * 
     * @type {string}
     * @memberof LoginRequestDTO
     */
    sessionSourceId: string;
    /**
     * 
     * @type {string}
     * @memberof LoginRequestDTO
     */
    userAgent: string;
}
/**
 * 
 * @export
 * @interface LoginResponseDTO
 */
export interface LoginResponseDTO {
    /**
     * 
     * @type {string}
     * @memberof LoginResponseDTO
     */
    accessToken: string;
    /**
     * 
     * @type {number}
     * @memberof LoginResponseDTO
     */
    expiresIn: number;
    /**
     * 
     * @type {string}
     * @memberof LoginResponseDTO
     */
    tokenType: string;
}
/**
 * 
 * @export
 * @interface PatchAgentProjectRequestDTO
 */
export interface PatchAgentProjectRequestDTO {
    /**
     * Human-readable agent project name. Value is trimmed before validation.
     * @type {string}
     * @memberof PatchAgentProjectRequestDTO
     */
    name?: string;
    /**
     * Optional project description. Empty or blank value can be normalized during patch processing.
     * @type {string}
     * @memberof PatchAgentProjectRequestDTO
     */
    description?: string;
    /**
     * Optional project-specific context. Empty or blank value can be normalized during patch processing.
     * @type {string}
     * @memberof PatchAgentProjectRequestDTO
     */
    context?: string | null;
}
/**
 * 
 * @export
 * @interface PatchAgentRequestDTO
 */
export interface PatchAgentRequestDTO {
    /**
     * Human-readable agent name. Value is trimmed before validation.
     * @type {string}
     * @memberof PatchAgentRequestDTO
     */
    name?: string;
    /**
     * Short description of the agent responsibility.
     * @type {string}
     * @memberof PatchAgentRequestDTO
     */
    description?: string;
    /**
     * Behavioral definition text used to guide agent execution.
     * @type {string}
     * @memberof PatchAgentRequestDTO
     */
    instruction?: string;
}
/**
 * 
 * @export
 * @interface PatchAgentRuleRequestDTO
 */
export interface PatchAgentRuleRequestDTO {
    /**
     * Updated rule title. Value is trimmed before validation.
     * @type {string}
     * @memberof PatchAgentRuleRequestDTO
     */
    title?: string;
    /**
     * Updated rule content. Value is trimmed before validation.
     * @type {string}
     * @memberof PatchAgentRuleRequestDTO
     */
    content?: string;
}
/**
 * 
 * @export
 * @interface ProjectAgentResponseDTO
 */
export interface ProjectAgentResponseDTO {
    /**
     * Agent identifier.
     * @type {string}
     * @memberof ProjectAgentResponseDTO
     */
    id: string;
    /**
     * Agent name.
     * @type {string}
     * @memberof ProjectAgentResponseDTO
     */
    name: string;
    /**
     * Agent description.
     * @type {string}
     * @memberof ProjectAgentResponseDTO
     */
    description?: string;
    /**
     * Agent lifecycle status.
     * @type {string}
     * @memberof ProjectAgentResponseDTO
     */
    status: ProjectAgentResponseDTOStatusEnum;
    /**
     * Agent creation timestamp (UTC).
     * @type {string}
     * @memberof ProjectAgentResponseDTO
     */
    createdAt: string;
    /**
     * Last agent update timestamp (UTC).
     * @type {string}
     * @memberof ProjectAgentResponseDTO
     */
    updatedAt: string;
    /**
     * Project-agent membership identifier.
     * @type {string}
     * @memberof ProjectAgentResponseDTO
     */
    membershipId?: string;
    /**
     * Membership creation timestamp (UTC).
     * @type {string}
     * @memberof ProjectAgentResponseDTO
     */
    attachedAt: string;
}


/**
 * @export
 */
export const ProjectAgentResponseDTOStatusEnum = {
    DRAFT: 'DRAFT',
    ACTIVE: 'ACTIVE',
    ARCHIVED: 'ARCHIVED',
    DELETED: 'DELETED'
} as const;
export type ProjectAgentResponseDTOStatusEnum = typeof ProjectAgentResponseDTOStatusEnum[keyof typeof ProjectAgentResponseDTOStatusEnum];

/**
 * 
 * @export
 * @interface ProjectAgentsResponseDTO
 */
export interface ProjectAgentsResponseDTO {
    /**
     * Agents attached to the project.
     * @type {Array<ProjectAgentResponseDTO>}
     * @memberof ProjectAgentsResponseDTO
     */
    items: Array<ProjectAgentResponseDTO>;
}
/**
 * 
 * @export
 * @interface ProjectConversationDTO
 */
export interface ProjectConversationDTO {
    /**
     * Conversation identifier.
     * @type {string}
     * @memberof ProjectConversationDTO
     */
    id: string;
    /**
     * Project identifier that owns this conversation.
     * @type {string}
     * @memberof ProjectConversationDTO
     */
    projectId: string;
    /**
     * Conversation type.
     * @type {string}
     * @memberof ProjectConversationDTO
     */
    type: ProjectConversationDTOTypeEnum;
    /**
     * Conversation title.
     * @type {string}
     * @memberof ProjectConversationDTO
     */
    title: string;
    /**
     * Conversation status.
     * @type {string}
     * @memberof ProjectConversationDTO
     */
    status: ProjectConversationDTOStatusEnum;
    /**
     * 
     * @type {Array<ProjectConversationParticipantDTO>}
     * @memberof ProjectConversationDTO
     */
    participants: Array<ProjectConversationParticipantDTO>;
    /**
     * Whether messaging is available for this conversation.
     * @type {boolean}
     * @memberof ProjectConversationDTO
     */
    canSendMessages: boolean;
    /**
     * Conversation creation timestamp (UTC).
     * @type {string}
     * @memberof ProjectConversationDTO
     */
    createdAt: string;
    /**
     * Last conversation update timestamp (UTC).
     * @type {string}
     * @memberof ProjectConversationDTO
     */
    updatedAt: string;
    /**
     * Last message timestamp (UTC).
     * @type {string}
     * @memberof ProjectConversationDTO
     */
    lastMessageAt?: string | null;
}


/**
 * @export
 */
export const ProjectConversationDTOTypeEnum = {
    DIRECT: 'DIRECT',
    MULTI_AGENT: 'MULTI_AGENT'
} as const;
export type ProjectConversationDTOTypeEnum = typeof ProjectConversationDTOTypeEnum[keyof typeof ProjectConversationDTOTypeEnum];

/**
 * @export
 */
export const ProjectConversationDTOStatusEnum = {
    ACTIVE: 'ACTIVE',
    DELETED: 'DELETED'
} as const;
export type ProjectConversationDTOStatusEnum = typeof ProjectConversationDTOStatusEnum[keyof typeof ProjectConversationDTOStatusEnum];

/**
 * 
 * @export
 * @interface ProjectConversationDetailsDTO
 */
export interface ProjectConversationDetailsDTO {
    /**
     * Conversation identifier.
     * @type {string}
     * @memberof ProjectConversationDetailsDTO
     */
    id: string;
    /**
     * Project identifier that owns this conversation.
     * @type {string}
     * @memberof ProjectConversationDetailsDTO
     */
    projectId: string;
    /**
     * 
     * @type {ProjectConversationProjectDTO}
     * @memberof ProjectConversationDetailsDTO
     */
    project?: ProjectConversationProjectDTO;
    /**
     * Conversation type.
     * @type {string}
     * @memberof ProjectConversationDetailsDTO
     */
    type: ProjectConversationDetailsDTOTypeEnum;
    /**
     * Conversation title.
     * @type {string}
     * @memberof ProjectConversationDetailsDTO
     */
    title: string;
    /**
     * Conversation status.
     * @type {string}
     * @memberof ProjectConversationDetailsDTO
     */
    status: ProjectConversationDetailsDTOStatusEnum;
    /**
     * 
     * @type {Array<ProjectConversationParticipantDTO>}
     * @memberof ProjectConversationDetailsDTO
     */
    participants: Array<ProjectConversationParticipantDTO>;
    /**
     * Ordered conversation messages. Empty for shell-only state.
     * @type {Array<AgentConversationMessageDTO>}
     * @memberof ProjectConversationDetailsDTO
     */
    messages: Array<AgentConversationMessageDTO>;
    /**
     * Whether messaging is available for this conversation.
     * @type {boolean}
     * @memberof ProjectConversationDetailsDTO
     */
    canSendMessages: boolean;
    /**
     * Conversation creation timestamp (UTC).
     * @type {string}
     * @memberof ProjectConversationDetailsDTO
     */
    createdAt: string;
    /**
     * Last conversation update timestamp (UTC).
     * @type {string}
     * @memberof ProjectConversationDetailsDTO
     */
    updatedAt: string;
    /**
     * Last message timestamp (UTC).
     * @type {string}
     * @memberof ProjectConversationDetailsDTO
     */
    lastMessageAt?: string | null;
}


/**
 * @export
 */
export const ProjectConversationDetailsDTOTypeEnum = {
    DIRECT: 'DIRECT',
    MULTI_AGENT: 'MULTI_AGENT'
} as const;
export type ProjectConversationDetailsDTOTypeEnum = typeof ProjectConversationDetailsDTOTypeEnum[keyof typeof ProjectConversationDetailsDTOTypeEnum];

/**
 * @export
 */
export const ProjectConversationDetailsDTOStatusEnum = {
    ACTIVE: 'ACTIVE',
    DELETED: 'DELETED'
} as const;
export type ProjectConversationDetailsDTOStatusEnum = typeof ProjectConversationDetailsDTOStatusEnum[keyof typeof ProjectConversationDetailsDTOStatusEnum];

/**
 * 
 * @export
 * @interface ProjectConversationParticipantDTO
 */
export interface ProjectConversationParticipantDTO {
    /**
     * Participant type.
     * @type {string}
     * @memberof ProjectConversationParticipantDTO
     */
    type: ProjectConversationParticipantDTOTypeEnum;
    /**
     * User participant identifier when participant type is USER.
     * @type {string}
     * @memberof ProjectConversationParticipantDTO
     */
    userId?: string | null;
    /**
     * Agent participant identifier when participant type is AGENT.
     * @type {string}
     * @memberof ProjectConversationParticipantDTO
     */
    agentId?: string | null;
    /**
     * Display name for participant.
     * @type {string}
     * @memberof ProjectConversationParticipantDTO
     */
    name?: string | null;
    /**
     * Participant description for AGENT entries.
     * @type {string}
     * @memberof ProjectConversationParticipantDTO
     */
    description?: string | null;
    /**
     * Participant source entity status.
     * @type {string}
     * @memberof ProjectConversationParticipantDTO
     */
    status: ProjectConversationParticipantDTOStatusEnum;
}


/**
 * @export
 */
export const ProjectConversationParticipantDTOTypeEnum = {
    USER: 'USER',
    AGENT: 'AGENT'
} as const;
export type ProjectConversationParticipantDTOTypeEnum = typeof ProjectConversationParticipantDTOTypeEnum[keyof typeof ProjectConversationParticipantDTOTypeEnum];

/**
 * @export
 */
export const ProjectConversationParticipantDTOStatusEnum = {
    ACTIVE: 'ACTIVE',
    ARCHIVED: 'ARCHIVED',
    DELETED: 'DELETED'
} as const;
export type ProjectConversationParticipantDTOStatusEnum = typeof ProjectConversationParticipantDTOStatusEnum[keyof typeof ProjectConversationParticipantDTOStatusEnum];

/**
 * 
 * @export
 * @interface ProjectConversationProjectDTO
 */
export interface ProjectConversationProjectDTO {
    /**
     * Project identifier.
     * @type {string}
     * @memberof ProjectConversationProjectDTO
     */
    id: string;
    /**
     * Project name.
     * @type {string}
     * @memberof ProjectConversationProjectDTO
     */
    name: string;
    /**
     * Project context text.
     * @type {string}
     * @memberof ProjectConversationProjectDTO
     */
    context?: string | null;
}
/**
 * 
 * @export
 * @interface ProjectConversationsResponseDTO
 */
export interface ProjectConversationsResponseDTO {
    /**
     * 
     * @type {Array<ProjectConversationDTO>}
     * @memberof ProjectConversationsResponseDTO
     */
    items: Array<ProjectConversationDTO>;
}
/**
 * 
 * @export
 * @interface RefreshAccessTokenRequestDTO
 */
export interface RefreshAccessTokenRequestDTO {
    /**
     * Opaque device/browser identifier generated by the client and persisted locally. Must map to an existing ACTIVE device session for this user.
     * @type {string}
     * @memberof RefreshAccessTokenRequestDTO
     */
    sessionSourceId: string;
}
/**
 * 
 * @export
 * @interface RefreshAccessTokenResponseDTO
 */
export interface RefreshAccessTokenResponseDTO {
    /**
     * Short-lived JWT access token.
     * @type {string}
     * @memberof RefreshAccessTokenResponseDTO
     */
    accessToken: string;
    /**
     * Access token TTL in seconds.
     * @type {number}
     * @memberof RefreshAccessTokenResponseDTO
     */
    expiresIn: number;
    /**
     * Token type (always Bearer).
     * @type {string}
     * @memberof RefreshAccessTokenResponseDTO
     */
    tokenType: RefreshAccessTokenResponseDTOTokenTypeEnum;
}


/**
 * @export
 */
export const RefreshAccessTokenResponseDTOTokenTypeEnum = {
    Bearer: 'Bearer'
} as const;
export type RefreshAccessTokenResponseDTOTokenTypeEnum = typeof RefreshAccessTokenResponseDTOTokenTypeEnum[keyof typeof RefreshAccessTokenResponseDTOTokenTypeEnum];

/**
 * 
 * @export
 * @interface RegisterUserDTO
 */
export interface RegisterUserDTO {
    /**
     * 
     * @type {string}
     * @memberof RegisterUserDTO
     */
    password: string;
    /**
     * 
     * @type {string}
     * @memberof RegisterUserDTO
     */
    email: string;
    /**
     * 
     * @type {string}
     * @memberof RegisterUserDTO
     */
    siteId?: string;
    /**
     * 
     * @type {string}
     * @memberof RegisterUserDTO
     */
    role: RegisterUserDTORoleEnum;
}


/**
 * @export
 */
export const RegisterUserDTORoleEnum = {
    SUPER_ADMIN: 'SUPER_ADMIN',
    ECOSYSTEM_OWNER: 'ECOSYSTEM_OWNER',
    SITE_ADMIN: 'SITE_ADMIN',
    SITE_USER: 'SITE_USER'
} as const;
export type RegisterUserDTORoleEnum = typeof RegisterUserDTORoleEnum[keyof typeof RegisterUserDTORoleEnum];

/**
 * 
 * @export
 * @interface ResendEmailVerificationResponseDTO
 */
export interface ResendEmailVerificationResponseDTO {
    /**
     * 
     * @type {string}
     * @memberof ResendEmailVerificationResponseDTO
     */
    message: string;
}
/**
 * 
 * @export
 * @interface ResponseRegisterUserDTO
 */
export interface ResponseRegisterUserDTO {
    /**
     * 
     * @type {string}
     * @memberof ResponseRegisterUserDTO
     */
    message?: string;
    /**
     * 
     * @type {number}
     * @memberof ResponseRegisterUserDTO
     */
    userId?: number;
    /**
     * 
     * @type {string}
     * @memberof ResponseRegisterUserDTO
     */
    status?: ResponseRegisterUserDTOStatusEnum;
}


/**
 * @export
 */
export const ResponseRegisterUserDTOStatusEnum = {
    PENDING_EMAIL_VERIFY: 'PENDING_EMAIL_VERIFY',
    ACTIVE: 'ACTIVE',
    INACTIVE: 'INACTIVE',
    BANNED: 'BANNED'
} as const;
export type ResponseRegisterUserDTOStatusEnum = typeof ResponseRegisterUserDTOStatusEnum[keyof typeof ResponseRegisterUserDTOStatusEnum];

/**
 * 
 * @export
 * @interface SiteOverviewDTO
 */
export interface SiteOverviewDTO {
    /**
     * 
     * @type {string}
     * @memberof SiteOverviewDTO
     */
    siteId: string;
    /**
     * 
     * @type {string}
     * @memberof SiteOverviewDTO
     */
    name: string;
    /**
     * 
     * @type {string}
     * @memberof SiteOverviewDTO
     */
    status: SiteOverviewDTOStatusEnum;
    /**
     * 
     * @type {string}
     * @memberof SiteOverviewDTO
     */
    type?: SiteOverviewDTOTypeEnum;
    /**
     * 
     * @type {string}
     * @memberof SiteOverviewDTO
     */
    description?: string;
    /**
     * 
     * @type {string}
     * @memberof SiteOverviewDTO
     */
    createdAt: string;
    /**
     * 
     * @type {string}
     * @memberof SiteOverviewDTO
     */
    updatedAt: string;
}


/**
 * @export
 */
export const SiteOverviewDTOStatusEnum = {
    DRAFT: 'DRAFT',
    PUBLISHED: 'PUBLISHED',
    ARCHIVED: 'ARCHIVED'
} as const;
export type SiteOverviewDTOStatusEnum = typeof SiteOverviewDTOStatusEnum[keyof typeof SiteOverviewDTOStatusEnum];

/**
 * @export
 */
export const SiteOverviewDTOTypeEnum = {
    PORTFOLIO: 'PORTFOLIO',
    BUSINESS: 'BUSINESS',
    BLOG: 'BLOG',
    STORE: 'STORE',
    LANDING: 'LANDING',
    OTHER: 'OTHER'
} as const;
export type SiteOverviewDTOTypeEnum = typeof SiteOverviewDTOTypeEnum[keyof typeof SiteOverviewDTOTypeEnum];

/**
 * 
 * @export
 * @interface SubmitChatExecutionResponseDTO
 */
export interface SubmitChatExecutionResponseDTO {
    /**
     * Created execution identifier.
     * @type {string}
     * @memberof SubmitChatExecutionResponseDTO
     */
    executionId: string;
    /**
     * Conversation identifier linked to this execution.
     * @type {string}
     * @memberof SubmitChatExecutionResponseDTO
     */
    conversationId: string;
    /**
     * User message identifier persisted during submit transaction.
     * @type {string}
     * @memberof SubmitChatExecutionResponseDTO
     */
    inputMessageId: string;
    /**
     * 
     * @type {ExecutionStatusDTO}
     * @memberof SubmitChatExecutionResponseDTO
     */
    status: ExecutionStatusDTO;
    /**
     * Execution acceptance timestamp (UTC).
     * @type {string}
     * @memberof SubmitChatExecutionResponseDTO
     */
    acceptedAt: string;
    /**
     * 
     * @type {ChatExecutionFailureDTO}
     * @memberof SubmitChatExecutionResponseDTO
     */
    error?: ChatExecutionFailureDTO | null;
    /**
     * Echoed idempotency key when provided.
     * @type {string}
     * @memberof SubmitChatExecutionResponseDTO
     */
    idempotencyKey?: string;
    /**
     * True when response is replayed from a previous equivalent submit.
     * @type {boolean}
     * @memberof SubmitChatExecutionResponseDTO
     */
    idempotencyReplayed?: boolean;
}
/**
 * 
 * @export
 * @interface SubmitConversationExecutionRequestDTO
 */
export interface SubmitConversationExecutionRequestDTO {
    /**
     * User message content to persist and execute.
     * @type {string}
     * @memberof SubmitConversationExecutionRequestDTO
     */
    message: string;
    /**
     * Optional client correlation key used for idempotent retries.
     * @type {string}
     * @memberof SubmitConversationExecutionRequestDTO
     */
    clientRequestId?: string;
}
/**
 * 
 * @export
 * @interface SubmitConversationExecutionResponseDTO
 */
export interface SubmitConversationExecutionResponseDTO {
    /**
     * Conversation identifier linked to this execution.
     * @type {string}
     * @memberof SubmitConversationExecutionResponseDTO
     */
    conversationId: string;
    /**
     * User message identifier persisted during submit transaction.
     * @type {string}
     * @memberof SubmitConversationExecutionResponseDTO
     */
    inputMessageId: string;
    /**
     * Indicates whether runtime execution dispatch was created.
     * @type {boolean}
     * @memberof SubmitConversationExecutionResponseDTO
     */
    runtimeDispatched: boolean;
    /**
     * Execution identifier only when runtime dispatch created execution.
     * @type {string}
     * @memberof SubmitConversationExecutionResponseDTO
     */
    executionId?: string | null;
    /**
     * 
     * @type {ExecutionStatusDTO}
     * @memberof SubmitConversationExecutionResponseDTO
     */
    executionStatus?: ExecutionStatusDTO;
}
/**
 * 
 * @export
 * @interface WorkspaceSiteCardResponseDTO
 */
export interface WorkspaceSiteCardResponseDTO {
    /**
     * 
     * @type {string}
     * @memberof WorkspaceSiteCardResponseDTO
     */
    siteId: string;
    /**
     * 
     * @type {string}
     * @memberof WorkspaceSiteCardResponseDTO
     */
    name: string;
    /**
     * 
     * @type {string}
     * @memberof WorkspaceSiteCardResponseDTO
     */
    status: WorkspaceSiteCardResponseDTOStatusEnum;
    /**
     * 
     * @type {string}
     * @memberof WorkspaceSiteCardResponseDTO
     */
    type?: WorkspaceSiteCardResponseDTOTypeEnum;
    /**
     * 
     * @type {string}
     * @memberof WorkspaceSiteCardResponseDTO
     */
    description?: string;
    /**
     * 
     * @type {string}
     * @memberof WorkspaceSiteCardResponseDTO
     */
    createdAt: string;
    /**
     * 
     * @type {string}
     * @memberof WorkspaceSiteCardResponseDTO
     */
    updatedAt: string;
}


/**
 * @export
 */
export const WorkspaceSiteCardResponseDTOStatusEnum = {
    DRAFT: 'DRAFT',
    PUBLISHED: 'PUBLISHED',
    ARCHIVED: 'ARCHIVED'
} as const;
export type WorkspaceSiteCardResponseDTOStatusEnum = typeof WorkspaceSiteCardResponseDTOStatusEnum[keyof typeof WorkspaceSiteCardResponseDTOStatusEnum];

/**
 * @export
 */
export const WorkspaceSiteCardResponseDTOTypeEnum = {
    PORTFOLIO: 'PORTFOLIO',
    BUSINESS: 'BUSINESS',
    BLOG: 'BLOG',
    STORE: 'STORE',
    LANDING: 'LANDING',
    OTHER: 'OTHER'
} as const;
export type WorkspaceSiteCardResponseDTOTypeEnum = typeof WorkspaceSiteCardResponseDTOTypeEnum[keyof typeof WorkspaceSiteCardResponseDTOTypeEnum];

/**
 * 
 * @export
 * @interface WorkspaceSitesResponseDTO
 */
export interface WorkspaceSitesResponseDTO {
    /**
     * 
     * @type {Array<WorkspaceSiteCardResponseDTO>}
     * @memberof WorkspaceSitesResponseDTO
     */
    items: Array<WorkspaceSiteCardResponseDTO>;
    /**
     * 
     * @type {number}
     * @memberof WorkspaceSitesResponseDTO
     */
    page: number;
    /**
     * 
     * @type {number}
     * @memberof WorkspaceSitesResponseDTO
     */
    size: number;
    /**
     * 
     * @type {boolean}
     * @memberof WorkspaceSitesResponseDTO
     */
    hasNext: boolean;
}
